﻿using System;

namespace Variaveis_2
{
    class Program
    {
        static void Main(string[] args)
        {
            string nome;
            int numero;
            decimal temperatura;
           
            
            
            Console.Write("Hello ");
            nome = "Bob";
            Console.Write(nome);
            Console.Write("! ");
            Console.Write(" You have ");
            numero = 3;
            Console.Write(numero);
            Console.Write(" in your inbox. ");
            Console.Write("The temperature is ");
            temperatura = 34.4m;
            Console.Write(temperatura);
            Console.Write(" Celsius");
        }
    }
}
