﻿using System;

namespace C_Sharp_Variáveis
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("A resolução abaixo é armazenado um dado em uma variável e depois utilizado");
            string firstName;
            string value = "fernando";
            firstName = "Bob";
            Console.WriteLine(firstName);
            firstName = "Beth";
            Console.WriteLine(firstName);
            firstName = "Conrad";
            Console.WriteLine(firstName);
            firstName = "Grant";
            Console.WriteLine(firstName);
            Console.WriteLine(value);

        }
    }
}
