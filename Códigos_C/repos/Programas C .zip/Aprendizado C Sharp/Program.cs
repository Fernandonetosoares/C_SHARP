﻿using System;

namespace Aprendizado_C_Sharp
{
    class Program
    {
        static void Main(string[] args)
        {
            // Uso do Console.Writeline para imprimir na tela conjuntos de caracteres
            Console.WriteLine("Olá mundo!");
            Console.Write("Olá ");
            Console.Write("Mundo");
            Console.WriteLine(" ");
            Console.WriteLine("b");
            Console.WriteLine("a");
            Console.WriteLine("t");
            Console.WriteLine("e");
            Console.WriteLine(125);
            Console.WriteLine(12.5m);
            Console.WriteLine(true);
            Console.WriteLine(false);
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
        }
    }
}
